<?php $this->load->view('style/contactCss'); ?>
<?php $this->load->view('base/menu'); ?>

<?php $this->load->view('pages/contactP'); ?>

<?php $this->load->view('base/newsletter'); ?>
<?php $this->load->view('base/footer'); ?>
<?php $this->load->view('style/contactScr'); ?>
