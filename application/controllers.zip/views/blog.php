<?php $this->load->view('style/blogCss'); ?>
<?php $this->load->view('base/menu'); ?>

<?php $this->load->view('pages/blogP'); ?>

<?php $this->load->view('base/newsletter'); ?>
<?php $this->load->view('base/footer'); ?>
<?php $this->load->view('style/blogScr'); ?>
