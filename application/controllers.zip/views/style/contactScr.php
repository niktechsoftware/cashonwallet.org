<script src="<?php echo base_url(); ?>assets/js/jquery-3.3.1.min.js"></script>
<script src="<?php echo base_url(); ?>assets/styles/bootstrap4/popper.js"></script>
<script src="<?php echo base_url(); ?>assets/styles/bootstrap4/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/greensock/TweenMax.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/greensock/TimelineMax.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/greensock/animation.gsap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/easing/easing.js"></script>
<!-- <script src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14258.931679587764!2d84.16648517047408!3d26.689023031588594!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x399398aff638ce5d%3A0xb30085849865fa69!2sTamakuhi+Raj%2C+Uttar+Pradesh+274407!5e0!3m2!1sen!2sin!4v1548760327394"></script> -->
<script src="<?php echo base_url(); ?>assets/js/contact_custom.js"></script>
</body>

</html>