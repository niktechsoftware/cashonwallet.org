<script src="<?php echo base_url(); ?>assets/js/jquery-3.3.1.min.js"></script>
<script src="<?php echo base_url(); ?>assets/styles/bootstrap4/popper.js"></script>
<script src="<?php echo base_url(); ?>assets/styles/bootstrap4/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/greensock/TweenMax.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/greensock/TimelineMax.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/scrollmagic/ScrollMagic.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/greensock/animation.gsap.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/greensock/ScrollToPlugin.min.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/OwlCarousel2-2.2.1/owl.carousel.js"></script>
<script src="<?php echo base_url(); ?>assets/plugins/easing/easing.js"></script>
<script src="<?php echo base_url(); ?>assets/js/product_custom.js"></script>
</body>

</html>