<?php $this->load->view('style/productCss'); ?>
<?php $this->load->view('base/menu'); ?>

<?php $this->load->view('pages/productP'); ?>

<?php $this->load->view('base/recent'); ?>
<?php $this->load->view('base/brands'); ?>
<?php $this->load->view('base/newsletter'); ?>
<?php $this->load->view('base/footer'); ?>
<?php $this->load->view('style/productScr'); ?>
