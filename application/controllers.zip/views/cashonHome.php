<?php $this->load->view('style/homeCss'); ?>

<?php $this->load->view('base/menu'); ?>
<?php $this->load->view('base/banner'); ?>
<?php $this->load->view('base/adverts'); ?>
<?php $this->load->view('base/bestsellers'); ?>
<?php $this->load->view('base/characteristics'); ?>
<?php $this->load->view('base/dow'); ?>
<?php //$this->load->view('base/popCat'); ?>
<?php //$this->load->view('base/banner2'); ?>
<?php // $this->load->view('base/hna'); ?>
<?php //$this->load->view('base/trends'); ?>
<?php //$this->load->view('base/reviews'); ?>
<?php $this->load->view('base/recent'); ?>
<?php $this->load->view('base/brands'); ?>
<?php $this->load->view('base/newsletter'); ?>
<?php $this->load->view('base/footer'); ?>

<?php $this->load->view('style/homeScr'); ?>

