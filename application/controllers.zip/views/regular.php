<?php $this->load->view('style/regularCss'); ?>
<?php $this->load->view('base/menu'); ?>

<?php $this->load->view('pages/regularP'); ?>

<?php $this->load->view('base/newsletter'); ?>
<?php $this->load->view('base/footer'); ?>
<?php $this->load->view('style/regularScr'); ?>
