<?php $this->load->view('style/blog_simpleCss'); ?>
<?php $this->load->view('base/menu'); ?>

<?php $this->load->view('pages/blog_simpleP'); ?>

<?php $this->load->view('base/newsletter'); ?>
<?php $this->load->view('base/footer'); ?>
<?php $this->load->view('style/blog_simpleScr'); ?>
