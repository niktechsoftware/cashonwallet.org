<?php $this->load->view('style/shopCss'); ?>
<?php $this->load->view('base/menu'); ?>

<?php $this->load->view('pages/shopP'); ?>

<?php $this->load->view('base/recent'); ?>
<?php $this->load->view('base/brands'); ?>
<?php $this->load->view('base/newsletter'); ?>
<?php $this->load->view('base/footer'); ?>
<?php $this->load->view('style/shopScr'); ?>
